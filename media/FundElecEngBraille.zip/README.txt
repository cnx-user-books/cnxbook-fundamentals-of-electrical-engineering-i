The Braille ready files for Rice University Foundations of Electrical 
Engineering I were prepared by importing Connexions course materials 
into Scientific Workplace, checking all text and math against original 
content, then converting the resulting file to Braille via Duxbury 
version 10.6.  The Duxbury files were then embossed with a Juliet Pro 
Embosser.

Figures that accompany the text were prepared in tactile format through 
a process of importing the images into Paint, enlarging them for full 
page sizing, and replacing text labels with Braille labels.  The resulting 
images were saved as jpegs, printed on heat sensitive paper and run through 
a heat treating unit to raise them.  The specific paper used was SwellTouch 
and the machine is a Pictures-In-A-Flash.

To use this file for creating a Braille document, the .zip file contains 
.dxb files ready for direct import into Duxbury for embossing using a standard 
embosser.  The figures can be printed for preparation as tactile images via a 
process such as described above.

The adaptive technology unit of Rice University Disability Support Services 
prepared these course materials in Braille.  
